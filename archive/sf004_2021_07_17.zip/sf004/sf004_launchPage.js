let w = 420;
let h = 265;

// <editor-fold> Main Panel
let panel = mkPanel({
  title: 'Soundflow #4 - Launch',
  onwindowresize: true,
  w: w,
  h: h
});
let canvas = panel.content;
// </editor-fold>

// <editor-fold> Title Text
let title = mkSpan({
  canvas: canvas,
  w: w,
  h: 24,
  top: 8,
  // left: 0,
  text: 'Soundflow #4 - Justin Yang',
  fontSize: 18,
  color: 'rgb(153,255,0)'
});
// </editor-fold>

// <editor-fold> Piece ID instructions
let pieceIDinstructions = mkSpan({
  canvas: canvas,
  w: w,
  h: 40,
  top: 40,
  // left: 0,
  text: 'Please enter an ID for this performance. All particants in the performance would use the same ID.',
  fontSize: 12,
  color: 'white'
});
// </editor-fold>
